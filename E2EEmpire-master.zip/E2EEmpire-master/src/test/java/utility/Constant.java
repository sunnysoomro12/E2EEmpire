package utility;

import java.time.format.DateTimeFormatter;

public class Constant {


    public static final Boolean SAUCE=false;
    public static final Boolean HEADLESS=true;
    public static final String SauceUsername="";
    public static final String SauceAccessKey="";
    public static final String ChromePathMAC="drivers/Chrome/chromedriver";
    public static final String ChromePathWIN="drivers/Chrome/chromedriver.exe";

    public static final String FirefoxPathMAC="drivers/chromedriver";
    public static final String FirefoxPathWIN="drivers/chromedriver.exe";


    public static final DateTimeFormatter AmericanDateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy");

    //region default
  //  public static String urlVariable = "staging";
    public static  String URL="https://www.empire.ca/insurance/buy-life-insurance";
    public static  String PortalURL="https://portal.mypl.empire.ca";
    public static  String OWLURL="https://em1.novinsoft.com/emshcore/Home";
    public static  String FFXURL="https://dev.ffx.empirelife.io/";

    public static  String Username="";
    public static  String Password="";

    /*
    public Constant(String UrlVariable, String UserName, String PassWord) {

        URL = "https://"+urlVariable+".empire.ca";
        Username = UserName;
        Password = PassWord;
    }
*/

    public String getURL()
    {
        return URL;
    }
    public String getUsername()
    {
        return Username;
    }
    public String getPassword()
    {
        return Password;
    }

}
