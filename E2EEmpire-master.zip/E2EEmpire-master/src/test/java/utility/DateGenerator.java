package utility;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.Calendar;
import java.util.Date;

public class DateGenerator {

    public String Today()
    {
        Date date = new Date();
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/YYYY");
        return dateFormat.format(date).toString();
    }

    public String Today(String offsetType, int offSet)
    {
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/YYYY");
        Calendar cal = Calendar.getInstance();

        if (offsetType.equalsIgnoreCase("day"))
        {
            cal.add(Calendar.DAY_OF_MONTH,offSet);
            return  dateFormat.format(cal.getTime());
        }
        else if (offsetType.equalsIgnoreCase("month"))
        {
            cal.add(Calendar.MONTH,offSet);
            return  dateFormat.format(cal.getTime());
        }
        else if(offsetType.equalsIgnoreCase("year"))
        {
            cal.add(Calendar.YEAR,offSet);
            return  dateFormat.format(cal.getTime());
        }

        else if(offsetType.equalsIgnoreCase("week"))
        {
            cal.add(Calendar.WEEK_OF_YEAR,offSet);
            return  dateFormat.format(cal.getTime());
        }

        return dateFormat.format(cal.getTime());
    }

    public String Tomorrow()
    {
        return LocalDate.now().plusDays(1).format(Constant.AmericanDateFormat);
    }

    public String NextMonday()
    {
        return LocalDate.now().with(TemporalAdjusters.next(DayOfWeek.MONDAY)).format(Constant.AmericanDateFormat);
    }

    public String WeeksAfterNextMonday(int weeks)
    {
        return LocalDate.now().with(TemporalAdjusters.next(DayOfWeek.MONDAY)).plusWeeks(weeks).format(Constant.AmericanDateFormat);
    }
}
