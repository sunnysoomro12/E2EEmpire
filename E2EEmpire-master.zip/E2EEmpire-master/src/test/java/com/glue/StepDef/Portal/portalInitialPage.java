package com.glue.StepDef.Portal;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.remote.RemoteWebDriver;
import pageFactory.PortalLogin.PortalLoginPage;

public class portalInitialPage {
    RemoteWebDriver HookDriver;
    public PortalLoginPage objPortalLoginPage;

    @Given("^the user is on the login page of user Portal$")
    public void the_user_is_on_the_login_page_of_user_Portal() {

        objPortalLoginPage = new PortalLoginPage(HookDriver);

        objPortalLoginPage.EnterUsername();
        objPortalLoginPage.EnterPassword();
        objPortalLoginPage.ClickSubmit();

    }

    @When("^the username and the password is entered$")
    public void the_username_and_the_password_is_entered() {

    }

    @Then("^basic portal validations are made$")
    public void basic_portal_validations_are_made() {

    }
}
