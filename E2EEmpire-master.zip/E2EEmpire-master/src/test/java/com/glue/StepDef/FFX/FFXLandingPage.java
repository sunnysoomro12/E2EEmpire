package com.glue.StepDef.FFX;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class FFXLandingPage {

    @Given("^the user is on the home page of the FFX website$")
    public void the_user_is_on_the_home_page_of_the_FFX_website() {

    }

    @When("^login button is clicked and valid credentials are entered$")
    public void login_button_is_clicked_and_valid_credentials_are_entered() {

    }

    @Then("^should take you to FFX home page$")
    public void should_take_you_to_FFX_home_page() {

    }

}
