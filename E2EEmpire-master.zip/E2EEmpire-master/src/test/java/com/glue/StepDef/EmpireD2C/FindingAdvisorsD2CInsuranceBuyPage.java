package com.glue.StepDef.EmpireD2C;

import com.glue.Hooks;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.remote.RemoteWebDriver;
import pageFactory.EmpireD2CHomePage.FindingAdvisorHomepage;
import pageFactory.EmpireD2CHomePage.InsuranceBuyElements;
import utility.RandomGenerator;

import java.util.concurrent.TimeUnit;

public class FindingAdvisorsD2CInsuranceBuyPage {
    RemoteWebDriver HookDriver;
    private  InsuranceBuyElements objInsuranceBuyElements;
    private  FindingAdvisorHomepage objFindingAdvisorHomepage;
    private RandomGenerator objRandomGenerator;
    String Fname,Lname;


    @Given("^the user is on the insurance buy page$")
    public void the_user_is_on_the_insurance_buy_page() {
        HookDriver = Hooks.driver;

        objInsuranceBuyElements = new InsuranceBuyElements(HookDriver);
        HookDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        objInsuranceBuyElements.FindAdvisorMenuBtnClick();

        objFindingAdvisorHomepage = new FindingAdvisorHomepage(HookDriver);

        objRandomGenerator = new RandomGenerator();
        Fname= objRandomGenerator.generateRandomString(5);
        Lname= objRandomGenerator.generateRandomString(5);

        HookDriver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
        objFindingAdvisorHomepage.EnterFirstName(Fname);
        HookDriver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
      //  objFindingAdvisorHomepage.EnterLastName(Lname);
    }

    @When("^on the insurance buy homepage fill in client information$")
    public void on_the_insurance_buy_homepage_fill_in_client_information() {

    }

    @Then("^click on the search button to get the list of the advisors$")
    public void click_on_the_search_button_to_get_the_list_of_the_advisors() {

    }
}
