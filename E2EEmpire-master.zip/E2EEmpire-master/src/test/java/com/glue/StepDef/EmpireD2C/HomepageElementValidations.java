package com.glue.StepDef.EmpireD2C;

import com.glue.Hooks;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.remote.RemoteWebDriver;
import pageFactory.EmpireD2CHomePage.HomepageElements;
import utility.RandomGenerator;

import java.util.concurrent.TimeUnit;

public class HomepageElementValidations {
    RemoteWebDriver HookDriver;
    private  HomepageElements objHomePageElements;
    private RandomGenerator objRandomGenerator;
    private String Fname,Lname= null;


    @Given("^the user is on the home page of the website$")
    public void the_user_is_on_the_home_page_of_the_website() {
        HookDriver = Hooks.driver;
        HookDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

        objHomePageElements = new HomepageElements(HookDriver);

        objHomePageElements.ScrollToFirstName();

        objRandomGenerator = new RandomGenerator();
        Fname= objRandomGenerator.generateRandomString(5);
        Lname= objRandomGenerator.generateRandomString(5);

        objHomePageElements.EnterFirstName(Fname);
        objHomePageElements.EnterFirstName(Lname);
}

    @When("^the required information is filled$")
    public void the_required_information_is_filled() {

    }

    @Then("^should provide the required information$")
    public void should_provide_the_required_information() {

    }

}
