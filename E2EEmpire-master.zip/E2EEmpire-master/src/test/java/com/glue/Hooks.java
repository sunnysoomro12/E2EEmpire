package com.glue;

import com.saucelabs.saucerest.SauceREST;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.*;
import org.openqa.selenium.Point;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.SessionId;
import pageFactory.Login;
import utility.Constant;

import java.awt.*;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class Hooks {
    public static RemoteWebDriver driver;
    public static SessionId session;
    public static Login objLogin;
    public static final Boolean SAUCE = Constant.SAUCE;
    public static final String SAUCE_USERNAME = Constant.SauceUsername;
    public static final String SAUCE_ACCESS_KEY = Constant.SauceAccessKey;
    public static final String SAUCE_URL = "https://" + SAUCE_USERNAME + ":" + SAUCE_ACCESS_KEY + "@ondemand.saucelabs.com:443/wd/hub";
    public static Constant constant;


    @Before(order=0)  //do stuff before atest
    public void openBrowser(Scenario scenario) throws MalformedURLException {
        DesiredCapabilities caps = DesiredCapabilities.chrome();
        caps.setCapability("platform", "Windows 10");
        caps.setCapability("version", "79.0");
        caps.setCapability("javascriptEnabled", true);
        caps.setCapability("acceptSslCerts", true);
        caps.setCapability("screenResolution", "1920x1080");
        caps.setCapability("name", scenario.getName());
        caps.setCapability("extendedDebugging", true);

        //String downloadFilepath = "download";//"/Users/macbook/Documents/GitHub/ap-e2e-splash/"; //NEED TO MAKE THIS WORK EVERYWHERE

       // String fileUploadedName = null;
        Path currentRelativePath = Paths.get("");
        String downloadFilepath = System.getProperty("user.dir")+ File.separator  + "downloads";

        //currentRelativePath.toAbsolutePath().toString() + "/downloads";
        /*if(SAUCE){
        downloadFilepath =System.getProperty("user.dir")+ File.separator  + "documents";
        }*/

        String os = System.getProperty("os.name").toLowerCase();
        Map<String, Object> prefs = new HashMap<String, Object>();
        prefs.put("profile.default_content_settings.popups", 0);
        prefs.put("download.default_directory", downloadFilepath);
        prefs.put("download.prompt_for_download","false");
        ChromeOptions options = new ChromeOptions();

        if (Constant.HEADLESS)
        {
            options.addArguments("headless");
            options.addArguments("disable-gpu");
            options.addArguments("--enable-features=NetworkService,NetworkServiceInProcess");
            //options.addArguments("NetworkServiceInProcess");
        }

        options.setExperimentalOption("prefs", prefs);
        caps.setCapability(ChromeOptions.CAPABILITY, options);


        if (!SAUCE) {
            if (os.contains("mac")) {
                System.setProperty("webdriver.chrome.driver", Constant.ChromePathMAC);

            } else {
                System.setProperty("webdriver.chrome.driver", Constant.ChromePathWIN);
            }

            driver = new ChromeDriver(caps);

            driver.manage().window().setSize(new Dimension(1920, 1080));
            java.awt.Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            Point position = new Point(0, 0);
            driver.manage().window().setPosition(position);

        } else {

            driver = new RemoteWebDriver(new URL(SAUCE_URL), caps);

            this.driver.setFileDetector(new LocalFileDetector());


        }



        if (scenario.getName().toLowerCase().contains("portal"))
        {
            session = driver.getSessionId();
            driver.get(Constant.PortalURL);
            /*
            objLogin.InputUsername(Constant.Username);
            objLogin.InputPassword(Constant.Password);
            objLogin.WaitForLoginButton(driver);
            objLogin.ClickOnLoginButton();
            */

        }
        else if(scenario.getName().toLowerCase().contains("FFX")){
            session = driver.getSessionId();
            driver.get(Constant.FFXURL);
            System.out.println();

        }
        else {

            session = driver.getSessionId();
            driver.get(Constant.URL);
        }
}


    @After //do stuff after test
    public void exit(Scenario scenario) {
        driver.close();

    }

}
