package modules;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class WaitStale
{
    public static void Execute(WebDriver driver, WebElement element)
    {
        WebDriverWait wait = new WebDriverWait(driver, 80);
        wait.until(ExpectedConditions.stalenessOf(element));
    }
}
