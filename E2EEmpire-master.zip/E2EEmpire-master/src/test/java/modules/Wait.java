package modules;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class Wait {

    public static void Execute(WebDriver driver, WebElement element){
        WebDriverWait wait = new WebDriverWait(driver, 80);
        wait.until(ExpectedConditions.visibilityOf(element));

    }


    public static void Execute(RemoteWebDriver driver, WebElement element, int timeout) {
        WebDriverWait wait = new WebDriverWait(driver, timeout);
        wait.until(ExpectedConditions.visibilityOf(element));
    }


    public static void ElementloadingWait(RemoteWebDriver driver, WebElement element,int timeout){     // CAN BE USED FOR PORTALS LOADING WINDOWS
        WebDriverWait wait = new WebDriverWait(driver, timeout);
        wait.until(ExpectedConditions.not((ExpectedConditions.visibilityOf(element))));

    }

}
