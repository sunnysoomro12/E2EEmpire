package modules;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class WaitTillText {
    public static void Execute(RemoteWebDriver driver, WebElement element, String text) {
        WebDriverWait wait = new WebDriverWait(driver, 80);
        wait.until(ExpectedConditions.textToBePresentInElement(element, text));

    }
}
