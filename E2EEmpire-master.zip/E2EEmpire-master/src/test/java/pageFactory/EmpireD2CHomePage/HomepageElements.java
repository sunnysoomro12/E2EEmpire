package pageFactory.EmpireD2CHomePage;

import modules.ScrollTo;
import modules.Wait;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class HomepageElements {

    RemoteWebDriver driver;
    public HomepageElements(RemoteWebDriver hookDriver) {

        this.driver=driver;
        PageFactory.initElements(driver,this);
    }

    @FindBy(how = How.NAME, using = "first_name")
    WebElement firstNameHomePage;

    @FindBy(how = How.NAME, using = "last_name")
    WebElement lastNameHomePage;

    @FindBy(how = How.NAME, using = "phone")
    WebElement phoneHomePage;

    @FindBy(how = How.NAME, using = "postal_code")
    WebElement postalcodeHomePage;

    @FindBy(how = How.NAME, using = "city")
    WebElement cityHomePage;

    @FindBy(how = How.NAME, using = "province")
    WebElement provinceHomePage;

    @FindBy(how = How.NAME, using = "email")
    WebElement emailHomePage;

    @FindBy(how = How.NAME, using = "verify_email")
    WebElement confirmEmailHomePage;



    public void ScrollToFirstName(){
        Wait.Execute(driver,firstNameHomePage);
        ScrollTo.JSWorkaroundScrolling(driver,firstNameHomePage);
    }


    public void EnterFirstName(String FName){
        Wait.Execute(driver,firstNameHomePage);
        firstNameHomePage.sendKeys(FName);
    }

    public void EnterLastName(String LName){
        Wait.Execute(driver,lastNameHomePage);
        lastNameHomePage.sendKeys(LName);
    }

    public void EnterPhoneNumber(){
        Wait.Execute(driver,phoneHomePage);
        phoneHomePage.click();
    }

    public void Enterpostalcode(){
        Wait.Execute(driver,postalcodeHomePage);
        postalcodeHomePage.click();
    }

    public void EnterCityName() {
        Wait.Execute(driver, cityHomePage);
        cityHomePage.click();
    }

    public void SelectProvince(String provName){
        Wait.Execute(driver,provinceHomePage);
        Select s = new Select(provinceHomePage);
        s.selectByValue(provName);

    }

}
