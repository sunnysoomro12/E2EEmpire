package pageFactory.EmpireD2CHomePage;

import modules.Wait;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class FindingAdvisorHomepage {

    RemoteWebDriver driver;
    public FindingAdvisorHomepage(RemoteWebDriver hookDriver) {

        this.driver=driver;
        PageFactory.initElements(driver,this);
    }

    @FindBy(how = How.NAME, using = "first_name")
    WebElement firstName;

    @FindBy(how = How.NAME, using = "last_name")
    WebElement lastName;

    @FindBy(how = How.NAME, using = "phone")
    WebElement phone;

    @FindBy(how = How.NAME, using = "postal_code")
    WebElement postalcode;

    @FindBy(how = How.NAME, using = "city")
    WebElement city;

    @FindBy(how = How.NAME, using = "province")
    WebElement province;

    @FindBy(how = How.NAME, using = "email")
    WebElement email;

    @FindBy(how = How.NAME, using = "verify_email")
    WebElement confirmEmail;



    public void EnterFirstName(String FName){
        Wait.Execute(driver,firstName);
        firstName.sendKeys(FName);
    }

    public void EnterLastName(String LName){
        Wait.Execute(driver,lastName);
        lastName.sendKeys(LName);
    }

    public void EnterPhoneNumber(){
        Wait.Execute(driver,phone);
        phone.click();
    }

    public void Enterpostalcode(){
        Wait.Execute(driver,postalcode);
        postalcode.click();
    }

    public void EnterCityName() {
        Wait.Execute(driver, city);
        city.click();
    }

    public void SelectProvince(String provName){
        Wait.Execute(driver,province);
        Select s = new Select(province);
        s.selectByValue(provName);

        }
}
