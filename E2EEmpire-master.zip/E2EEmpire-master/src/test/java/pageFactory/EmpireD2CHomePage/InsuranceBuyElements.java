package pageFactory.EmpireD2CHomePage;

import modules.Wait;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class InsuranceBuyElements {

    RemoteWebDriver driver;

    public InsuranceBuyElements(RemoteWebDriver driver){  //need this always
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }

    @FindBy(how = How.XPATH, using = "//*[@id='main-nav']/div[2]/ul/li[1]/a")
    WebElement findAnAdvisor;

    @FindBy(how = How.XPATH, using = "//*[@id='main-nav']/div[2]/ul/li[2]/a")
    WebElement getQuote;

    @FindBy(how = How.XPATH, using = "//*[@id='main-nav']/div[2]/ul/li[3]/a")
    WebElement needsAnalysis;

    @FindBy(how = How.XPATH, using = "//*[@id='main-nav']/div[2]/ul/li[4]/a")
    WebElement aboutLifeInsurance;

    @FindBy(how = How.XPATH, using = "//*[@id='main-nav']/div[2]/ul/li[5]/a")
    WebElement contactUs;



    public void FindAdvisorMenuBtnClick(){
    Wait.Execute(driver,findAnAdvisor);
        findAnAdvisor.click();
    }

    public void GetQuoteMenuBtnClick(){
        Wait.Execute(driver,findAnAdvisor);
        getQuote.click();
    }
    public void NeedsAnalysisMenuBtnClick(){
        Wait.Execute(driver,findAnAdvisor);
        needsAnalysis.click();
    }

    public void AboutLifeInsuranceMenuBtnClick(){
        Wait.Execute(driver,findAnAdvisor);
        aboutLifeInsurance.click();
    }

    public void ContactUsMenuBtnClick(){
        Wait.Execute(driver,findAnAdvisor);
        contactUs.click();
    }




}
