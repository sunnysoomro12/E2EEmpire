package pageFactory;

import modules.Wait;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Login {
    RemoteWebDriver driver;
    @FindBy(how = How.NAME, using = "username")
    WebElement userName;

    @FindBy(how = How.NAME, using = "Password")
    WebElement password;


    @FindBy(how = How.NAME, using = "submit")
    WebElement loginButton;

    @FindBy(how = How.CSS, using = "#product_logo")
    WebElement juiceLogo;

    @FindBy(how = How.CSS, using = "#login_holder > table.login_form > tbody > tr:nth-child(2) > td:nth-child(3) > div.login_buttonformError.parentFormundefined.formError.orangePopup > div")
    WebElement wrongUsernamePassword;

    public void WaitForUsernameField(RemoteWebDriver driver) {
        Wait.Execute(driver, userName);
    }

    public void WaitForjuiceLogo(RemoteWebDriver driver) {
        Wait.Execute(driver, juiceLogo);
    }

    public void InputUsername(String un) {
        Wait.Execute(this.driver, userName);
        userName.sendKeys(un);
    }

    public void InputPassword(String pw) {
        Wait.Execute(this.driver, password);
        password.sendKeys(pw);
    }

    public void ClickOnLoginButton() {
        Wait.Execute(this.driver, loginButton);
        loginButton.click();
    }

    public Login(RemoteWebDriver driver) {  //need this always
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void WaitForWrongUsernamePassword(RemoteWebDriver driver) {
        Wait.Execute(driver, wrongUsernamePassword);
    }

    public boolean IsLoginFail() {

        return wrongUsernamePassword.getText().toString().contains("Wrong username/password");
    }

    public void WrongLoginCredentials()
    {

        driver.findElement(By.name("Wrong username/password"));
        //wrongUsernamePassword.isDisplayed();
    }


    public void WaitForLoginButton(RemoteWebDriver driver){
        Wait.Execute(driver,loginButton);

    }
}

