package pageFactory.PortalLogin;

import modules.Wait;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PortalLoginPage {

    RemoteWebDriver driver;

    public PortalLoginPage(RemoteWebDriver driver){  //need this always
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }

    @FindBy(how = How.NAME, using = "username")
    WebElement userName;

    @FindBy(how = How.NAME, using = "password")
    WebElement password;

    @FindBy(how = How.NAME, using = "submit")
    WebElement SubmitBtn;

    public void EnterUsername(){
        Wait.Execute(driver,userName);
        userName.sendKeys("754440user1");
    }

    public void EnterPassword(){
        Wait.Execute(driver,password);
        password.sendKeys("asdasdasd");
    }

    public void ClickSubmit(){
        Wait.Execute(driver,SubmitBtn);
        SubmitBtn.click();
    }
}
